# Komplexpraktikum Paralleles Rechnen - Aufgabe B

Folgende Dateien sind enthalten:
- results: Ordner mit allen Messergebnissen vom Hochleistungsrechner Taurus
- pics: Diagramme als png & svg
- Bericht: enthält den Praktikumsbericht
- objdump: Enthält die dis­as­sem­b­lie­rten Textdateien der Original Binaries
- batch_gcc.sh und batch_icc.sh: sbatch files
- video.sh: Skript zum Erstellen von Videos aus dem Output
- gof_parallel.c: Quellcode
- analyzer.py: Python Skript zum generieren der Diagramme aus den Messdaten
